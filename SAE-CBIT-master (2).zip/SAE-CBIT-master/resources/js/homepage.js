var btnContainer = document.getElementsById("main-nav");

// Get all buttons with class="btn" inside the container
var btns = btnContainer.getElementsByClassName("btn");

// Loop through the buttons and add the active class to the current/clicked button
for (var i = 0; i < btns.length; i++) {
  btns[i].addEventListener("click", function() {
    var current = document.getElementsByClassName("active");

    // If there's no active class
    if (current.length > 0) {
      current[0].className = current[0].className.replace("active", "");
    }

    // Add the active class to the current/clicked button
    this.className += " active";
  });
}

function showmatter(){
	var elems = document.getElementsByClassName('matter');
	for (var i=0;i<elems.length;i++)
	{
	//elems[i].style.	mouseover-transition='all 1s ease';
		elems[i].style.display = 'block';
	}
}

function fixmatter(){
	var elems = document.getElementsByClassName('matter');
	for (var i=0;i<elems.length;i++)
	{
  	elems[i].style.display = 'block';
	}
}


function gal_images(){
	var im = document.getElementsByClassName('gif');
	for (var i=0;i<im.length;i++)
	{
		im[i].style.display='none';
	}
	var ele = document.getElementsByClassName('imgs');
	for (var i=0;i<ele.length;i++)
	{
		ele[i].style.display='block';
	}
}


function videos(){
	var im = document.getElementsByClassName('imgs');
	for (var i=0;i<im.length;i++)
	{
		im[i].style.display='none';
	}
	var ele = document.getElementsByClassName('gif');
	for (var i=0;i<ele.length;i++)
	{
		ele[i].style.display='block';
	}
}



function entire_gal(){
	var im = document.getElementsByClassName('imgs');
	for (var i=0;i<im.length;i++)
	{
		im[i].style.display='block';
	}
	var ele = document.getElementsByClassName('gif');
	for (var i=0;i<ele.length;i++)
	{
		ele[i].style.display='block';
	}
}